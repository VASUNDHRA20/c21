var movingRect,fixedRect;


function setup() {
  createCanvas(800,400);
 movingRect= createSprite(400, 200, 100, 50);
 fixedRect= createSprite(200, 200, 50, 100);
 movingRect.shapeColor="green"
 fixedRect.shapeColor="green"

 movingRect.velocityX=-3;
fixedRect.velocityX=3;
}

function draw() {
  background("pink"); 
bounceOff(movingRect,fixedRect)

  if(isTouching(movingRect,fixedRect) ){
    movingRect.shapeColor="red"
   fixedRect.shapeColor="red"
  }
  else{
    movingRect.shapeColor="green"
    fixedRect.shapeColor="green"
  } 
  drawSprites();
}